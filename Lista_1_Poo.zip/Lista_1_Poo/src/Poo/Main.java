package Poo;

import java.util.Scanner;
import java.lang.Math;

public class Main {
    
    public static void main(String[] args) {
        
        Scanner entrada = new Scanner(System.in	);
        System.out.println("Digite o primeiro numero real");
        double NumReal1 = entrada.nextDouble();
        System.out.println("Digite o segundo numero real");
					 double NumReal2 = entrada.nextDouble();
//1- Abs
        System.out.print("Abs Primeiro Numero: ");
        double resultAbs1 = Math.abs(NumReal1);
        System.out.println(resultAbs1);
        System.out.print("Abs Segundo Numero: ");
        double resultAbs2 = Math.abs(NumReal2);
        System.out.println(resultAbs2);
//2-Ceil
        System.out.print("Ceil Primeiro Numero: ");
        double resultCeil1 = Math.ceil(NumReal1);
        System.out.println(resultCeil1);
        System.out.print("Ceil Segundo Numero: ");
        double resultCeil2 = Math.ceil(NumReal2);
        System.out.println(resultCeil2);
//3-Cos
        System.out.print("Cos Primeiro Numero: ");
        double resultCos1 = Math.cos(NumReal1);
        System.out.println(resultCos1);
        System.out.print("Cos Segundo Numero: ");
        double resultCos2 = Math.cos(NumReal2);
        System.out.println(resultCos2);
//4-Exp
        System.out.print("Exp Primeiro Numero: ");
        double resultExp1 = Math.exp(NumReal1);
        System.out.println(resultExp1);
        System.out.print("Exp Segundo Numero: ");
        double resultExp2 = Math.exp(NumReal2);
        System.out.println(resultExp2);
//5-Floor
        System.out.print("Floor Primeiro Numero: ");
        double resultFloor1 = Math.floor(NumReal1);
        System.out.println(resultFloor1);
        System.out.print("Floor Segundo Numero: ");
        double resultFloor2 = Math.floor(NumReal2);
        System.out.println(resultFloor2);
//6-Log
        System.out.print("Log Primeiro Numero: ");
        double resultLog1 = Math.log(NumReal1);
        System.out.println(resultLog1);
        System.out.print("Log Segundo Numero: ");
        double resultLog2 = Math.log(NumReal2);
        System.out.println(resultLog2);
//7-Max
        double resultNumMax = Math.max(NumReal1,NumReal2);
        System.out.println("O numero maximo entre os dois é : " + resultNumMax);
       
//8-Min
        Math.min(NumReal1,NumReal2);	
//9-Pow
       double ResultPow = Math.pow(NumReal1,NumReal2);
        System.out.println(ResultPow);
//10-Sqrt
        Math.sqrt(NumReal1);
        
        
    }
    
}
